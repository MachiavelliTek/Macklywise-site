/* Macklywise backend layer (Supabase + Cloudflare Turnstile). Does nothing until assets/config.js has keys. */
(function(){
var C=window.MW_CONFIG||{},BE=window.BE={on:!!(C.supabaseUrl&&C.supabaseAnonKey)};
if(!BE.on)return;
var sb=null,snap="{}",UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-/i,$=function(i){return document.getElementById(i)};
function lib(src){return new Promise(function(res){var s=document.createElement("script");s.src=src;s.async=true;s.onload=function(){res(true)};s.onerror=function(){res(false)};document.head.appendChild(s)})}
BE.url=function(k){return C.supabaseUrl+"/storage/v1/object/public/"+k.slice(3)};
BE.me=function(){return BE.user?BE.user.username:null};
async function errMsg(e){try{var j=await e.context.json();if(j&&j.error)return j.error}catch(_){}return "Something went wrong. Please try again."}
/* ---- Cloudflare Turnstile: invisible unless the visitor looks suspicious ---- */
function tt(){return new Promise(function(res){
  if(!C.turnstileSiteKey||!window.turnstile){res("");return}
  var box=$("tsb");if(!box){box=document.createElement("div");box.id="tsb";box.style.cssText="position:fixed;left:50%;bottom:90px;transform:translateX(-50%);z-index:200";document.body.appendChild(box)}
  box.innerHTML="";var id;
  id=window.turnstile.render(box,{sitekey:C.turnstileSiteKey,appearance:"interaction-only",callback:function(t){res(t);setTimeout(function(){try{window.turnstile.remove(id)}catch(_){}},400)},"error-callback":function(){toast("Security check failed. Please retry.");res("")},"timeout-callback":function(){res("")}});
})}
async function call(fn,body){var t=await tt();if(!t){toast("Please complete the security check and try again.");return null}
  body.token=t;var r=await sb.functions.invoke(fn,{body:body});if(r.error){toast(await errMsg(r.error));return null}return r.data}
/* ---- load shared data into the app's state ---- */
async function load(){
  var ses=(await sb.auth.getSession()).data.session,q=function(t,f){return sb.from(t).select(f||"*")};BE.user=null;BE.admin=false;
  var R=await Promise.all([q("products","id,category,slot,name,description,price,format,media,cover,file_name,file_size"),q("testimonials").order("created_at",{ascending:false}),q("public_comments").order("created_at"),q("public_profiles"),q("badges"),q("site_settings"),q("public_like_counts"),q("public_comment_like_counts")]);
  var D=R.map(function(x){return x.data||[]}),pr=D[0],tm=D[1],cm=D[2],pp=D[3],bd=D[4],ss=D[5],lc=D[6],cc=D[7];
  S.pr={};CATS.forEach(function(c){S.pr[c]=[]});
  pr.forEach(function(r){S.pr[r.category][r.slot]={n:r.name,d:r.description||"",p:+r.price,f:r.format||"",m:r.media||[],cv:r.cover||null,fl:r.file_name?{n:r.file_name,sz:r.file_size}:null}});rbP();
  var idu={};S.u={};pp.forEach(function(r){idu[r.id]=r.username;S.u[r.username]={n:r.display_name||r.username,hide:!!r.hidden,av:r.avatar||null,t:+new Date(r.created_at),bd:[],rv:[],rd:[],bt:{},id:r.id}});
  bd.forEach(function(r){var u=idu[r.user_id];if(u)S.u[u].bd.push(r.badge)});
  S.tm=tm.map(function(t){return{id:t.id,name:t.name,text:t.body,media:t.media||null,d:+new Date(t.created_at),likes:0,lb:[],comments:[]}});
  var TM={},CM={};S.tm.forEach(function(t){TM[t.id]=t});
  lc.forEach(function(r){if(TM[r.testimonial_id])TM[r.testimonial_id].likes=r.n});
  cm.forEach(function(r){var t=TM[r.testimonial_id];if(!t)return;var c={id:r.id,t:r.body,d:+new Date(r.created_at),lb:[],n:"Member"};if(r.user_id&&idu[r.user_id]){c.u=idu[r.user_id];c.a=0}else c.a=1;t.comments.push(c);CM[r.id]=c});
  cc.forEach(function(r){var c=CM[r.comment_id];if(c)for(var i=0;i<r.n;i++)c.lb.push("·")});
  var g=function(k){var x=ss.find(function(y){return y.key===k});return x?x.value:""};S.wa=g("whatsapp");S.mer=g("merchant_display");S.o=[];S.pay=[];
  if(ses){
    var me=(await sb.from("profiles").select("*").eq("id",ses.user.id).maybeSingle()).data;
    if(me&&S.u[me.username]){
      BE.user={id:me.id,username:me.username,role:me.role};
      BE.admin=(await sb.rpc("is_admin")).data===true;
      var ml=(await sb.from("likes").select("testimonial_id").eq("user_id",me.id)).data||[];ml.forEach(function(r){var t=TM[r.testimonial_id];if(t)t.lb.push(me.username)});
      var mc=(await sb.from("comment_likes").select("comment_id").eq("user_id",me.id)).data||[];mc.forEach(function(r){if(CM[r.comment_id]){CM[r.comment_id].lb.pop();CM[r.comment_id].lb.push(me.username)}});
      var od=(await sb.from("orders").select("*").order("created_at")).data||[];
      S.o=od.map(function(r){return{id:r.id,u:idu[r.user_id]||"member",it:r.items||[],tot:+r.total,t:+new Date(r.created_at),paid:r.status==="paid"?1:0}});
      var pays=(await sb.from("payments").select("id,user_id,items,amount,phone_last4,reference,status,created_at").order("created_at",{ascending:false})).data||[];
      S.pay=pays.map(function(r){return{id:r.id,u:idu[r.user_id]||"member",it:(r.items||[]).map(function(x){return{i:CATS.indexOf(x.category)*12+x.slot,n:x.n,p:x.p,q:x.q}}),amt:+r.amount,ph:r.phone_last4,t:+new Date(r.created_at),st:r.status,ref:BE.admin?r.reference:"",dl:0}});
      try{S.u[me.username].rd=JSON.parse(localStorage.getItem("mwrd")||"[]")}catch(_){}
      if(BE.admin){
        var dls=(await sb.from("downloads").select("payment_id")).data||[],n={};dls.forEach(function(x){n[x.payment_id]=(n[x.payment_id]||0)+1});S.pay.forEach(function(x){x.dl=n[x.id]||0});
        var al=(await sb.from("likes").select("testimonial_id,user_id")).data||[];S.tm.forEach(function(t){t.lb=[]});al.forEach(function(r){var t=TM[r.testimonial_id];if(t&&idu[r.user_id])t.lb.push(idu[r.user_id])});S.tm.forEach(function(t){t.likes=t.lb.length});
        var ac=(await sb.from("comments").select("id,user_id")).data||[];ac.forEach(function(r){var c=CM[r.id];if(c&&idu[r.user_id]){if(!c.u){c.u=idu[r.user_id]}}});
        var acl=(await sb.from("comment_likes").select("comment_id,user_id")).data||[];Object.keys(CM).forEach(function(k){CM[k].lb=[]});acl.forEach(function(r){var c=CM[r.comment_id];if(c&&idu[r.user_id])c.lb.push(idu[r.user_id])});
        var rv=(await sb.from("badge_revokes").select("user_id,badge")).data||[];rv.forEach(function(r){var u=idu[r.user_id];if(u)S.u[u].rv.push(r.badge)});
      }
    }
  }
  snap=snapshot();
}
function snapshot(){return JSON.stringify({pr:S.pr,tm:S.tm.map(function(t){return{id:t.id,cm:t.comments.map(function(c){return c.id})}}),o:S.o.map(function(o){return{id:o.id,paid:o.paid}}),bd:Object.keys(S.u).reduce(function(a,u){a[u]=S.u[u].bd.slice();return a},{}),wa:S.wa||"",mer:S.mer||""})}
/* ---- admin edits are saved by diff; the database (RLS + 2-step login) decides whether each write is allowed ---- */
var busy=false,again=false;
async function sync(){
  if(!BE.admin)return;if(busy){again=true;return}busy=true;
  try{
    var old=JSON.parse(snap),cur=JSON.parse(snapshot()),nm=function(q){return q&&q.n&&q.p>0?q:null},E=function(r){if(r&&r.error)throw new Error(r.error.message)};
    for(var ci=0;ci<CATS.length;ci++)for(var k=0;k<12;k++){var c=CATS[ci],a=nm(((old.pr||{})[c]||[])[k]),b=nm((cur.pr[c]||[])[k]);if(JSON.stringify(a)===JSON.stringify(b))continue;
      if(b){var row={category:c,slot:k,name:b.n,description:b.d||"",price:b.p,format:b.f||"",media:b.m||[],cover:b.cv||null};
        if(b.fl&&b.fl.path){row.file_path=b.fl.path;row.file_name=b.fl.n;row.file_size=b.fl.sz}else if(!b.fl){row.file_path=null;row.file_name=null;row.file_size=null}
        E(await sb.from("products").upsert(row,{onConflict:"category,slot"}))}
      else E(await sb.from("products").delete().eq("category",c).eq("slot",k))}
    for(var t of S.tm){if(!UUID.test(t.id)){var r=await sb.from("testimonials").insert({name:t.name,body:t.text||"",media:t.media||null}).select("id").single();E(r);if(r.data)t.id=r.data.id}}
    for(var o of old.tm){if(!S.tm.some(function(x){return x.id===o.id}))E(await sb.from("testimonials").delete().eq("id",o.id))}
    for(var t2 of S.tm){var ot=old.tm.find(function(x){return x.id===t2.id});if(!ot)continue;var ids=t2.comments.map(function(c){return c.id});for(var cid of ot.cm)if(ids.indexOf(cid)<0)E(await sb.from("comments").delete().eq("id",cid))}
    for(var od of S.o){var po=old.o.find(function(x){return x.id===od.id});if(po&&po.paid!==od.paid)E(await sb.from("orders").update({status:od.paid?"paid":"pending"}).eq("id",od.id))}
    for(var p2 of old.o)if(!S.o.some(function(x){return x.id===p2.id}))E(await sb.from("orders").delete().eq("id",p2.id));
    for(var u of Object.keys(S.u)){var nb=S.u[u].bd,ob=(old.bd||{})[u]||[];for(var bb of nb)if(ob.indexOf(bb)<0)E(await sb.from("badges").upsert({user_id:S.u[u].id,badge:bb}));for(var b2 of ob)if(nb.indexOf(b2)<0){E(await sb.from("badges").delete().eq("user_id",S.u[u].id).eq("badge",b2));E(await sb.from("badge_revokes").upsert({user_id:S.u[u].id,badge:b2}))}}
    if((old.wa||"")!==(cur.wa||""))E(await sb.from("site_settings").upsert({key:"whatsapp",value:cur.wa||""}));
    if((old.mer||"")!==(cur.mer||""))E(await sb.from("site_settings").upsert({key:"merchant_display",value:cur.mer||""}));
    snap=snapshot();
  }catch(e){toast("Could not save: "+e.message)}
  busy=false;if(again){again=false;sync()}
}
BE.sv=function(){try{var m=BE.me();if(m&&S.u[m])localStorage.setItem("mwrd",JSON.stringify(S.u[m].rd||[]))}catch(_){}clearTimeout(BE._t);BE._t=setTimeout(sync,350)};
/* ---- uploads: public media vs the PRIVATE locked-file bucket ---- */
BE.up=async function(f,folder){var ext=(f.name.split(".").pop()||"bin").toLowerCase().replace(/[^a-z0-9]/g,"").slice(0,5)||"bin",path=folder+"/"+Date.now()+"-"+Math.random().toString(36).slice(2,8)+"."+ext;
  var r=await sb.storage.from("media").upload(path,f,{contentType:f.type||undefined,upsert:false});if(r.error){toast("Upload failed: "+r.error.message);return null}return{id:"sb:media/"+path,k:kind(f),n:f.name}};
BE.put=function(f){return BE.up(f,AT==="t"?"testimonials":"products")};
BE.putPriv=async function(f){var safe=f.name.replace(/[^a-zA-Z0-9._-]/g,"_").slice(-80),path="files/"+Date.now()+"-"+Math.random().toString(36).slice(2,8)+"-"+safe;
  var r=await sb.storage.from("deliverables").upload(path,f,{upsert:false});if(r.error){toast("Upload failed: "+r.error.message);return null}return{id:"priv:"+path,path:path}};
BE.del=async function(k){if(k.indexOf("priv:")===0)await sb.storage.from("deliverables").remove([k.slice(5)]);else await sb.storage.from("media").remove([k.slice(9)])};
/* ---- members ---- */
async function after(){await load();rbP();go()}
BE.su=async function(){var u=$("au").value.trim().toLowerCase(),n=$("an").value.trim(),e=($("ae")||{value:""}).value.trim(),p=$("ap").value;
  if(!/^[a-z0-9]{3,20}$/.test(u))return toast("Username: 3 to 20 letters or numbers.");
  if(!/^\S+@\S+\.\S+$/.test(e))return toast("Enter a valid email address.");
  if(p.length<10||p!==$("ap2").value)return toast("Password: 10+ characters, and both must match.");
  var t=await tt();if(!t)return toast("Please complete the security check.");
  var r=await sb.auth.signUp({email:e,password:p,options:{captchaToken:t,data:{username:u,display_name:n||u}}});
  if(r.error)return toast(/database error/i.test(r.error.message)?"That username is taken.":r.error.message);
  if(r.data.session){await after();toast("Welcome to Macklywise!")}else toast("Almost there! Check your email to confirm your account, then log in.")};
BE.li=async function(){var e=$("au").value.trim(),p=$("ap").value,t=await tt();if(!t)return toast("Please complete the security check.");
  var r=await sb.auth.signInWithPassword({email:e,password:p,options:{captchaToken:t}});if(r.error)return toast("Wrong email or password.");await after();toast("Welcome back!")};
BE.lo=async function(){await sb.auth.signOut();await after()};
BE.ps=async function(){var m=BE.me();if(!m)return;var f=$("pfa").files[0],name=$("pfn").value.trim()||m,hide=$("pfh").checked,av=S.u[m].av;
  if(f){if(kind(f)!=="image")return toast("Please choose an image.");var up=await BE.up(f,"avatars/"+BE.user.id);if(!up)return;av=up.id}
  var r=await sb.from("profiles").update({display_name:name,hidden:hide,avatar:av}).eq("id",BE.user.id);if(r.error)return toast("Could not save: "+r.error.message);
  Object.assign(S.u[m],{n:name,hide:hide,av:av});toast("Profile saved.");go()};
BE.lk=async function(id){var m=BE.me();if(!m)return toast("Log in to like.");var t=T(id),had=(t.lb||[]).indexOf(m)>=0;
  var r=had?await sb.from("likes").delete().eq("testimonial_id",id).eq("user_id",BE.user.id):await sb.from("likes").insert({testimonial_id:id});if(r.error)return toast("Could not update the like.");
  if(had){t.lb=t.lb.filter(function(x){return x!==m});t.likes=Math.max(0,(t.likes||0)-1)}else{t.lb=(t.lb||[]).concat(m);t.likes=(t.likes||0)+1}rc(id,!ge("cm"+id).hidden)};
BE.lc=async function(id,j){var m=BE.me();if(!m)return toast("Log in to like comments.");var c=T(id).comments[j],had=(c.lb||[]).indexOf(m)>=0;
  var r=had?await sb.from("comment_likes").delete().eq("comment_id",c.id).eq("user_id",BE.user.id):await sb.from("comment_likes").insert({comment_id:c.id});if(r.error)return toast("Could not update the like.");
  c.lb=had?c.lb.filter(function(x){return x!==m}):(c.lb||[]).concat(m);rc(id,true)};
BE.post=async function(id){var x=$("ct"+id).value.trim();if(!x)return;var m=BE.me();if(!m){toast("Please log in to comment.");location.hash="#profile";return}
  var rv=$("cr"+id).checked,r=await call("secure-write",{action:"comment",data:{testimonial_id:id,body:x,reveal:rv}});if(!r)return;
  T(id).comments.push({id:r.id,t:x,d:Date.now(),u:m,a:rv?0:1,lb:[]});rc(id,true)};
BE.rec=async function(src){var it;if(src==="c")it=items().map(function(x){return{i:x.p.i,q:x.q}});else{if(svc(P[src]))return;it=[{i:src,q:1}]}if(!it.length)return;
  if(!BE.me()){toast("Tip: sign up to track your orders.");return}
  var r=await call("secure-write",{action:"order",data:{items:it.map(function(x){return{category:CATS[Math.floor(x.i/12)],slot:x.i%12,q:x.q}})}});if(!r)return;
  S.o.push({id:r.id,u:BE.me(),it:r.items,tot:+r.total,t:Date.now(),paid:0});snap=snapshot();toast("Order saved to your history.");hdr()};
/* ---- EcoCash payments: all money logic lives on the server ---- */
window.PAYX_B={
  initiate:async function(l,ph){var t=await tt();if(!t)throw new Error("Please complete the security check and try again.");
    var r=await sb.functions.invoke("pay-initiate",{body:{items:l.map(function(x){return{category:CATS[Math.floor(x.i/12)],slot:x.i%12,q:x.q}}),phone:ph,token:t}});if(r.error)throw new Error(await errMsg(r.error));return r.data},
  status:async function(id){var r=await sb.functions.invoke("pay-status",{body:{id:id}});if(r.error)throw new Error(await errMsg(r.error));if(r.data.status==="paid"&&!S.pay.some(function(x){return x.id===id})){load().then(function(){})}return r.data},
  download:async function(id,i){var r=await sb.functions.invoke("download",{body:{payment_id:id,i:i}});if(r.error)return toast(await errMsg(r.error));
    var a=document.createElement("a");a.href=r.data.url;a.rel="noopener";document.body.appendChild(a);a.click();a.remove()}};
/* ---- admin: real account + 2-step code (Supabase MFA). The 4-click entry stays, the PIN is gone ---- */
BE.gate=function(){var g=document.createElement("div");g.className="ov";g.id="gate";
  g.innerHTML='<div class="c" style="max-width:340px;width:100%"><h3>Session timeout</h3><p class="m">Enter your login to log out of this page, or exit.</p><div id="gf"><input id="ge1" type="email" autocomplete="username" placeholder="Email"><input id="gp" type="password" autocomplete="current-password" placeholder="Password" style="margin-top:6px" onkeydown="event.key===\'Enter\'&&gok()"></div><div id="gq" hidden></div><p class="fm" id="gerr" style="color:#d33;min-height:18px"></p><div class="row"><button class="btn" onclick="gok()">Log out</button><button class="btn o" onclick="ge(\'gate\').remove()">Exit</button></div></div>';
  document.body.appendChild(g);$("ge1").focus()};
async function fin(){BE.step="";$("gate").remove();await load();rbP();adm("p");var n=elig().length;if(n)toast(n+" badge approval"+(n>1?"s":"")+" waiting in Admin")}
BE.gok=async function(){var er=$("gerr");er.textContent="";
  if(BE.step==="code"){var v=await sb.auth.mfa.challengeAndVerify({factorId:BE.fid,code:$("gc").value.trim()});if(v.error){er.textContent="Incorrect code.";return}return fin()}
  var e=$("ge1").value.trim(),p=$("gp").value,t=await tt();if(!t){er.textContent="Security check not completed.";return}
  var r=await sb.auth.signInWithPassword({email:e,password:p,options:{captchaToken:t}});if(r.error){er.textContent="Incorrect login.";return}
  var me=(await sb.from("profiles").select("role").eq("id",r.data.user.id).maybeSingle()).data;
  if(!me||me.role!=="admin"){await sb.auth.signOut();er.textContent="Incorrect login.";return}
  var a=(await sb.auth.mfa.getAuthenticatorAssuranceLevel()).data;if(a&&a.currentLevel==="aal2")return fin();
  var fs=(await sb.auth.mfa.listFactors()).data,f=fs&&fs.totp&&fs.totp[0],q='<p class="m">Enter the 6-digit code from your authenticator app.</p>';
  if(f){BE.fid=f.id}else{var en=await sb.auth.mfa.enroll({factorType:"totp"});if(en.error){er.textContent=en.error.message;return}BE.fid=en.data.id;
    q='<p class="m">One-time setup: scan this with Google Authenticator or Authy, then enter the 6-digit code.</p><img alt="" src="'+en.data.totp.qr_code+'" style="width:160px;height:160px;background:#fff"><p class="fm" style="word-break:break-all">'+en.data.totp.secret+'</p>'}
  $("gf").hidden=true;$("gq").hidden=false;$("gq").innerHTML=q+'<input id="gc" inputmode="numeric" maxlength="6" placeholder="123456" onkeydown="event.key===\'Enter\'&&gok()">';BE.step="code";$("gc").focus()};
BE.adx=async function(){await sb.auth.signOut();var a=$("adm");if(a)a.remove();await load();rbP();go()};
BE.sp=async function(){var a=$("p1").value;if(a.length<12||a!==$("p2").value)return toast("Use at least 12 characters and make both match.");var r=await sb.auth.updateUser({password:a});toast(r.error?r.error.message:"Password updated.")};
/* ---- start ---- */
BE.ready=(async function(){
  await Promise.all([lib("https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/dist/umd/supabase.min.js"),C.turnstileSiteKey?lib("https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit"):0]);
  if(!window.supabase){console.warn("Backend library blocked");return}
  sb=window.supabase.createClient(C.supabaseUrl,C.supabaseAnonKey,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:false}});
  try{await load()}catch(e){console.warn(e)}
  await new Promise(function(r){document.readyState==="loading"?document.addEventListener("DOMContentLoaded",r):r()});
  rbP();go();
})();
})();
