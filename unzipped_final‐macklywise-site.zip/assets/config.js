/* Public settings. Safe to publish: the anon key and Turnstile SITE key are meant to be public.
   NEVER put a service_role key, Paynow key or Turnstile secret in any file in this repository.
   Leave these empty to run the shop without a backend (orders go to WhatsApp). */
window.MW_CONFIG = { supabaseUrl: "", supabaseAnonKey: "", turnstileSiteKey: "" };
