-- ============================================================================
-- MACKLYWISE SECURE BACKEND  (run once: Supabase > SQL Editor > New query > Run)
-- Principles: deny by default. Every table has Row Level Security. Clients can
-- never write money, prices, roles or file paths. Payments are created and
-- confirmed only by server code (Edge Functions with the service role).
-- ============================================================================
create extension if not exists pgcrypto;

-- ---------- profiles ----------
create table public.profiles(
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null check (username ~ '^[a-z0-9]{3,20}$'),
  display_name text check (char_length(display_name) <= 60),
  avatar text,
  hidden boolean not null default false,
  role text not null default 'member' check (role in ('member','admin')),
  created_at timestamptz not null default now());
alter table public.profiles enable row level security;

-- admin = role 'admin' in this table AND a session that passed 2-step login (aal2)
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists(select 1 from public.profiles where id = auth.uid() and role = 'admin')
     and coalesce(auth.jwt() ->> 'aal','') = 'aal2' $$;
grant execute on function public.is_admin() to anon, authenticated;

create policy "profile own/admin read" on public.profiles for select using (id = auth.uid() or public.is_admin());
create policy "profile own update" on public.profiles for update using (id = auth.uid()) with check (id = auth.uid());
revoke all on public.profiles from anon, authenticated;
grant select on public.profiles to authenticated;
grant update (display_name, avatar, hidden) on public.profiles to authenticated;  -- role can never be self-edited

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare u text := lower(coalesce(new.raw_user_meta_data ->> 'username',''));
begin
  if u !~ '^[a-z0-9]{3,20}$' then raise exception 'Invalid username'; end if;
  insert into public.profiles(id, username, display_name)
  values (new.id, u, left(coalesce(new.raw_user_meta_data ->> 'display_name', u), 60));
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

create view public.public_profiles as
  select id, username,
         case when hidden then null else display_name end as display_name,
         case when hidden then null else avatar end as avatar,
         hidden, created_at
  from public.profiles;
grant select on public.public_profiles to anon, authenticated;

-- ---------- products (file_path is private: never readable by any client) ----------
create table public.products(
  id uuid primary key default gen_random_uuid(),
  category text not null check (category in ('Workflows','Ebooks & Guides','Apps','Strategy PDFs','Logos','Websites','Domains')),
  slot int not null check (slot between 0 and 11),
  name text not null check (char_length(name) between 1 and 120),
  description text not null default '' check (char_length(description) <= 1200),
  price numeric(10,2) not null check (price > 0 and price <= 100000),
  format text not null default '' check (char_length(format) <= 60),
  media jsonb not null default '[]',
  cover jsonb,
  file_path text, file_name text, file_size bigint,
  unique (category, slot));
alter table public.products enable row level security;
create policy "products read" on public.products for select using (true);
create policy "products admin write" on public.products for all using (public.is_admin()) with check (public.is_admin());
revoke all on public.products from anon, authenticated;
grant select (id,category,slot,name,description,price,format,media,cover,file_name,file_size) on public.products to anon, authenticated;
grant insert, update, delete on public.products to authenticated;   -- RLS limits this to admin

-- ---------- testimonials, comments, likes ----------
create table public.testimonials(
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 80),
  body text not null default '' check (char_length(body) <= 2000),
  media jsonb, created_at timestamptz not null default now());
alter table public.testimonials enable row level security;
create policy "t read" on public.testimonials for select using (true);
create policy "t admin" on public.testimonials for all using (public.is_admin()) with check (public.is_admin());
revoke all on public.testimonials from anon, authenticated;
grant select on public.testimonials to anon, authenticated;
grant insert, update, delete on public.testimonials to authenticated;

create table public.comments(
  id uuid primary key default gen_random_uuid(),
  testimonial_id uuid not null references public.testimonials(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 500),
  reveal boolean not null default true,
  created_at timestamptz not null default now());
alter table public.comments enable row level security;
create policy "c own/admin read" on public.comments for select using (user_id = auth.uid() or public.is_admin());
create policy "c own/admin delete" on public.comments for delete using (user_id = auth.uid() or public.is_admin());
revoke all on public.comments from anon, authenticated;   -- inserts only via the secure-write function (Turnstile + rate limit)
grant select, delete on public.comments to authenticated;
create view public.public_comments as   -- anonymous comments never expose who wrote them
  select id, testimonial_id, body, created_at, case when reveal then user_id end as user_id from public.comments;
grant select on public.public_comments to anon, authenticated;

create table public.likes(
  testimonial_id uuid references public.testimonials(id) on delete cascade,
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  primary key (testimonial_id, user_id));
alter table public.likes enable row level security;
create policy "l read" on public.likes for select using (user_id = auth.uid() or public.is_admin());
create policy "l insert" on public.likes for insert with check (user_id = auth.uid());
create policy "l delete" on public.likes for delete using (user_id = auth.uid());
revoke all on public.likes from anon, authenticated; grant select, insert, delete on public.likes to authenticated;
create view public.public_like_counts as select testimonial_id, count(*)::int as n from public.likes group by 1;
grant select on public.public_like_counts to anon, authenticated;

create table public.comment_likes(
  comment_id uuid references public.comments(id) on delete cascade,
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  primary key (comment_id, user_id));
alter table public.comment_likes enable row level security;
create policy "cl read" on public.comment_likes for select using (user_id = auth.uid() or public.is_admin());
create policy "cl insert" on public.comment_likes for insert with check (user_id = auth.uid());
create policy "cl delete" on public.comment_likes for delete using (user_id = auth.uid());
revoke all on public.comment_likes from anon, authenticated; grant select, insert, delete on public.comment_likes to authenticated;
create view public.public_comment_like_counts as select comment_id, count(*)::int as n from public.comment_likes group by 1;
grant select on public.public_comment_like_counts to anon, authenticated;

-- ---------- badges, settings ----------
create table public.badges(user_id uuid references auth.users(id) on delete cascade, badge text check (badge in ('tc','ts','wz')), awarded_at timestamptz not null default now(), primary key (user_id, badge));
alter table public.badges enable row level security;
create policy "b read" on public.badges for select using (true);
create policy "b admin" on public.badges for all using (public.is_admin()) with check (public.is_admin());
revoke all on public.badges from anon, authenticated; grant select on public.badges to anon, authenticated; grant insert, update, delete on public.badges to authenticated;
create table public.badge_revokes(user_id uuid references auth.users(id) on delete cascade, badge text, primary key (user_id, badge));
alter table public.badge_revokes enable row level security;
create policy "br admin" on public.badge_revokes for all using (public.is_admin()) with check (public.is_admin());
revoke all on public.badge_revokes from anon, authenticated; grant select, insert, update, delete on public.badge_revokes to authenticated;
create table public.site_settings(key text primary key check (key in ('whatsapp','merchant_display')), value text not null check (char_length(value) <= 60));
alter table public.site_settings enable row level security;
create policy "s read" on public.site_settings for select using (true);
create policy "s admin" on public.site_settings for all using (public.is_admin()) with check (public.is_admin());
revoke all on public.site_settings from anon, authenticated; grant select on public.site_settings to anon, authenticated; grant insert, update, delete on public.site_settings to authenticated;

-- ---------- orders (WhatsApp / manual) and DIRECT SALES (EcoCash payments) ----------
create table public.orders(id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id), items jsonb not null, total numeric(10,2) not null, status text not null default 'pending' check (status in ('pending','paid')), created_at timestamptz not null default now());
alter table public.orders enable row level security;
create policy "o own/admin read" on public.orders for select using (user_id = auth.uid() or public.is_admin());
create policy "o admin update" on public.orders for update using (public.is_admin()) with check (public.is_admin());
create policy "o admin delete" on public.orders for delete using (public.is_admin());
revoke all on public.orders from anon, authenticated; grant select, delete on public.orders to authenticated; grant update (status) on public.orders to authenticated;

create table public.payments(
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id),
  items jsonb not null,                       -- server-built snapshot: names and prices from the products table
  amount numeric(10,2) not null check (amount > 0),
  currency text not null default 'USD',
  phone_last4 text,                           -- the full phone number is never stored
  reference text unique not null,
  gateway_ref text, poll_url text, gateway_status text,
  status text not null default 'initiated' check (status in ('initiated','pending','paid','failed')),
  failure_reason text, paid_at timestamptz,
  created_at timestamptz not null default now());
alter table public.payments enable row level security;
create policy "p own/admin read" on public.payments for select using (user_id = auth.uid() or public.is_admin());
revoke all on public.payments from anon, authenticated;    -- no client can insert, edit or delete a payment, ever
grant select (id,user_id,items,amount,currency,phone_last4,reference,status,failure_reason,paid_at,created_at) on public.payments to authenticated;

create table public.downloads(id bigint generated always as identity primary key, payment_id uuid not null references public.payments(id), user_id uuid not null, product_id uuid, ip text, at timestamptz not null default now());
alter table public.downloads enable row level security;
create policy "d admin read" on public.downloads for select using (public.is_admin());
revoke all on public.downloads from anon, authenticated; grant select on public.downloads to authenticated;

-- ---------- rate limiting (used by Edge Functions and triggers) ----------
create table public.rate_hits(k text not null, at timestamptz not null default now());
create index on public.rate_hits(k, at);
alter table public.rate_hits enable row level security;
revoke all on public.rate_hits from anon, authenticated;
create or replace function public.hit_limit(p_key text, p_max int, p_secs int) returns boolean
language plpgsql security definer set search_path = public as $$
declare n int;
begin
  delete from public.rate_hits where at < now() - interval '1 day';
  insert into public.rate_hits(k) values (p_key);
  select count(*) into n from public.rate_hits where k = p_key and at > now() - make_interval(secs => p_secs);
  return n <= p_max;
end $$;
revoke execute on function public.hit_limit(text,int,int) from public, anon, authenticated;
grant execute on function public.hit_limit(text,int,int) to service_role;

create or replace function public.rl_trigger() returns trigger language plpgsql as $$
declare n int; lim int := tg_argv[0]::int; secs int := tg_argv[1]::int;
begin
  execute format('select count(*) from %I.%I where user_id = $1 and %s > now() - make_interval(secs => $2)', tg_table_schema, tg_table_name, tg_argv[2]) into n using new.user_id, secs;
  if n >= lim then raise exception 'Too many requests, slow down'; end if;
  return new;
end $$;
create trigger rl_comments before insert on public.comments for each row execute function public.rl_trigger(5, 60, 'created_at');
create trigger rl_orders   before insert on public.orders   for each row execute function public.rl_trigger(5, 3600, 'created_at');

-- ---------- storage ----------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values
  ('media','media',true, 26214400, array['image/jpeg','image/png','image/webp','image/gif','image/avif','video/mp4','video/webm','audio/mpeg','application/pdf'])
  on conflict (id) do update set public = true, file_size_limit = 26214400, allowed_mime_types = excluded.allowed_mime_types;
insert into storage.buckets (id, name, public, file_size_limit) values ('deliverables','deliverables', false, 52428800)
  on conflict (id) do update set public = false, file_size_limit = 52428800;   -- PRIVATE: only signed, short-lived links

create policy "media public read" on storage.objects for select using (bucket_id = 'media');
create policy "media admin write" on storage.objects for insert to authenticated with check (bucket_id = 'media' and (name like 'products/%' or name like 'testimonials/%') and public.is_admin());
create policy "media admin delete" on storage.objects for delete to authenticated using (bucket_id = 'media' and (name like 'products/%' or name like 'testimonials/%') and public.is_admin());
create policy "avatar own write" on storage.objects for insert to authenticated with check (bucket_id = 'media' and name like 'avatars/' || auth.uid()::text || '/%');
create policy "avatar own delete" on storage.objects for delete to authenticated using (bucket_id = 'media' and name like 'avatars/' || auth.uid()::text || '/%');
create policy "deliverables admin upload" on storage.objects for insert to authenticated with check (bucket_id = 'deliverables' and public.is_admin());
create policy "deliverables admin delete" on storage.objects for delete to authenticated using (bucket_id = 'deliverables' and public.is_admin());
-- there is deliberately NO select policy on 'deliverables': nobody can list or read files directly.

-- ---------- make yourself admin (after you sign up on the site, run with YOUR email) ----------
-- update public.profiles set role = 'admin' where id = (select id from auth.users where email = 'you@example.com');
