import { admin, J, pre, userOf, limit, ipOf, CATS } from "../_shared/common.ts";
// Files are private. This is the only door: paid + owner + short-lived signed link + audit log.
Deno.serve(async (req) => {
  const p = pre(req); if (p) return p;
  const u = await userOf(req); if (!u) return J({ error: "Please log in." }, 401);
  if (!(await limit("dl:" + u.id, 30, 3600))) return J({ error: "Too many downloads. Try again later." }, 429);
  let b: any; try { b = await req.json(); } catch { return J({ error: "Bad request" }, 400); }
  const i = parseInt(b.i); if (!(i >= 0 && i < 84)) return J({ error: "Bad request" }, 400);
  const cat = CATS[Math.floor(i / 12)], slot = i % 12;
  const { data: pay } = await admin.from("payments").select("id,items,status").eq("id", String(b.payment_id ?? "")).eq("user_id", u.id).maybeSingle();
  if (!pay || pay.status !== "paid") return J({ error: "Locked until payment succeeds." }, 403);
  const line = pay.items.find((x: any) => x.category === cat && x.slot === slot); if (!line) return J({ error: "Not part of this purchase." }, 403);
  const { count } = await admin.from("downloads").select("id", { count: "exact", head: true }).eq("payment_id", pay.id).eq("product_id", line.product_id);
  if ((count ?? 0) >= 10) return J({ error: "Download limit reached. Contact us for help." }, 429);
  const { data: pr } = await admin.from("products").select("file_path,file_name").eq("id", line.product_id).maybeSingle();
  if (!pr?.file_path) return J({ error: "No file is attached to this product yet." }, 404);
  const { data: s } = await admin.storage.from("deliverables").createSignedUrl(pr.file_path, 60, { download: pr.file_name ?? true });
  if (!s) return J({ error: "File unavailable." }, 500);
  await admin.from("downloads").insert({ payment_id: pay.id, user_id: u.id, product_id: line.product_id, ip: ipOf(req) });
  return J({ url: s.signedUrl });
});
