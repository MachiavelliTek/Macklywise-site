import { admin } from "./common.ts";
import { poll } from "./paynow.ts";
const OK = ["paid", "awaiting delivery", "delivered"], BAD = ["cancelled", "disputed", "refunded"];
// The ONLY place a payment can become 'paid'. It asks the gateway directly (signed), so a forged webhook can never unlock a file.
export async function settle(p: any) {
  if (p.status === "paid" || !p.poll_url) return p.status as string;
  const g = await poll(p.poll_url), st = (g["status"] ?? "").toLowerCase();
  if (g["reference"] !== p.reference) return p.status as string;
  const done = (patch: Record<string, unknown>) => admin.from("payments").update({ ...patch, gateway_status: st }).eq("id", p.id).neq("status", "paid");   // idempotent
  if (OK.includes(st)) {
    if (Math.abs(Number(g["amount"]) - Number(p.amount)) > 0.005) { await done({ status: "failed", failure_reason: "Amount mismatch, needs manual review" }); return "failed"; }
    await done({ status: "paid", paid_at: new Date().toISOString() }); return "paid";
  }
  if (BAD.includes(st)) { await done({ status: "failed", failure_reason: "Not approved (" + st + ")" }); return "failed"; }
  return p.status as string;
}
