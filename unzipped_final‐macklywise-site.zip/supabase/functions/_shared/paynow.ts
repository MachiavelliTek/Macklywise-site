// Paynow Zimbabwe "mobile express checkout" adapter (EcoCash). Verify against Paynow's sandbox before going live.
import { timingSafe } from "./common.ts";
const ID = Deno.env.get("PAYNOW_ID")!, KEY = Deno.env.get("PAYNOW_KEY")!;
const ENDPOINT = "https://www.paynow.co.zw/interface/remotetransaction";
async function sha512(s: string) { const b = await crypto.subtle.digest("SHA-512", new TextEncoder().encode(s)); return [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, "0")).join("").toUpperCase(); }
const sign = (vals: string[]) => sha512(vals.join("") + KEY);
export async function verify(body: string) {
  const o: Record<string, string> = {}, keys: string[] = [];
  for (const [k, v] of new URLSearchParams(body)) { o[k.toLowerCase()] = v; keys.push(k.toLowerCase()); }
  const calc = await sign(keys.filter((k) => k !== "hash").map((k) => o[k]));
  return { ok: timingSafe((o["hash"] ?? "").toUpperCase(), calc), o };   // every gateway message must carry a valid signature
}
export async function initiate(p: { reference: string; amount: string; phone: string; email: string; returnurl: string; resulturl: string; info: string }) {
  const f: [string, string][] = [["id", ID], ["reference", p.reference], ["amount", p.amount], ["additionalinfo", p.info], ["returnurl", p.returnurl], ["resulturl", p.resulturl], ["authemail", p.email], ["phone", p.phone], ["method", "ecocash"], ["status", "Message"]];
  const hash = await sign(f.map((x) => x[1]));
  const r = await fetch(ENDPOINT, { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams([...f, ["hash", hash]]) });
  const v = await verify(await r.text());
  if (!v.ok) throw new Error("Gateway signature check failed");
  if ((v.o["status"] ?? "").toLowerCase() !== "ok") throw new Error(v.o["error"] ?? "Gateway refused the request");
  return { pollurl: v.o["pollurl"], gwref: v.o["paynowreference"] };
}
export async function poll(pollurl: string) {
  if (new URL(pollurl).hostname !== "www.paynow.co.zw") throw new Error("Untrusted poll URL");   // SSRF guard
  const r = await fetch(pollurl, { method: "POST" });
  const v = await verify(await r.text());
  if (!v.ok) throw new Error("Gateway signature check failed");
  return v.o;
}
