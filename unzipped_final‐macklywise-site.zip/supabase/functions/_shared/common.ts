import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";
export const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });
export const ORIGIN = Deno.env.get("ALLOWED_ORIGIN") ?? "https://macklywise.com";
export const CATS = ["Workflows","Ebooks & Guides","Apps","Strategy PDFs","Logos","Websites","Domains"];
export const cors = { "Access-Control-Allow-Origin": ORIGIN, "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS", "Vary": "Origin" };
export const J = (b: unknown, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { ...cors, "Content-Type": "application/json", "Cache-Control": "no-store" } });
export const pre = (req: Request) => req.method === "OPTIONS" ? new Response(null, { headers: cors }) : req.method !== "POST" ? J({ error: "Method not allowed" }, 405) : null;
export const ipOf = (req: Request) => req.headers.get("cf-connecting-ip") ?? req.headers.get("x-forwarded-for")?.split(",")[0].trim() ?? null;
export async function userOf(req: Request) {
  const jwt = (req.headers.get("authorization") ?? "").replace(/^Bearer\s+/i, "");
  if (!jwt) return null;
  const { data } = await admin.auth.getUser(jwt);   // verified by Supabase Auth, never decoded blindly
  return data.user ?? null;
}
export async function turnstile(token: string, ip: string | null) {
  if (!token || token.length > 2048) return false;
  const r = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", { method: "POST", body: new URLSearchParams({ secret: Deno.env.get("TURNSTILE_SECRET")!, response: token, ...(ip ? { remoteip: ip } : {}) }) });
  const j = await r.json().catch(() => ({}));
  return j.success === true;
}
export async function limit(key: string, max: number, secs: number) {
  const { data } = await admin.rpc("hit_limit", { p_key: key, p_max: max, p_secs: secs });
  return data === true;
}
export function timingSafe(a: string, b: string) {
  if (a.length !== b.length) return false;
  let d = 0; for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return d === 0;
}
export function normPhone(s: string) { const m = /^(?:263|0)(7[78]\d{7})$/.exec(s.replace(/[\s\-+]/g, "")); return m ? "0" + m[1] : null; }
