import { admin, J, pre, userOf, limit, CATS } from "../_shared/common.ts";
import { settle } from "../_shared/settle.ts";
Deno.serve(async (req) => {
  const p = pre(req); if (p) return p;
  const u = await userOf(req); if (!u) return J({ error: "Please log in." }, 401);
  if (!(await limit("ps:" + u.id, 90, 60))) return J({ error: "Slow down." }, 429);
  let b: any; try { b = await req.json(); } catch { return J({ error: "Bad request" }, 400); }
  const { data: pay } = await admin.from("payments").select("*").eq("id", String(b.id ?? "")).eq("user_id", u.id).maybeSingle();   // owner only
  if (!pay) return J({ status: "failed", reason: "Payment not found." });
  let status = pay.status as string;
  if (status === "initiated" || status === "pending") { try { status = await settle(pay); } catch (_) { /* keep waiting */ } }
  if (status !== "paid") return J({ status, reason: status === "failed" ? (pay.failure_reason ?? "The payment was not approved.") : undefined });
  const items = [];
  for (const x of pay.items) {
    const { data: pr } = await admin.from("products").select("file_path").eq("id", x.product_id).maybeSingle();
    items.push({ i: CATS.indexOf(x.category) * 12 + x.slot, n: x.n, file: !!pr?.file_path });
  }
  return J({ status, amount: pay.amount, items });
});
