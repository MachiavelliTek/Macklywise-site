import { admin, J, pre, userOf, turnstile, limit, ipOf, normPhone, ORIGIN } from "../_shared/common.ts";
import { initiate } from "../_shared/paynow.ts";
// Starts an EcoCash payment. The price is read from the database, never from the browser.
Deno.serve(async (req) => {
  const p = pre(req); if (p) return p;
  const u = await userOf(req); if (!u) return J({ error: "Please log in first." }, 401);
  let b: any; try { b = await req.json(); } catch { return J({ error: "Bad request" }, 400); }
  if (!(await turnstile(String(b.token ?? ""), ipOf(req)))) return J({ error: "Security check failed. Please try again." }, 403);
  if (!(await limit("pay:" + u.id, 5, 600))) return J({ error: "Too many attempts. Please wait a few minutes." }, 429);
  const phone = normPhone(String(b.phone ?? "")); if (!phone) return J({ error: "Enter a valid EcoCash number, like 0771234567." }, 400);
  const raw = Array.isArray(b.items) ? b.items.slice(0, 20) : []; if (!raw.length) return J({ error: "Nothing to pay for." }, 400);
  const lines: any[] = []; let total = 0;
  for (const it of raw) {
    const q = Math.min(Math.max(parseInt(it.q) || 1, 1), 20);
    const { data: pr } = await admin.from("products").select("id,category,slot,name,price").eq("category", String(it.category)).eq("slot", parseInt(it.slot)).maybeSingle();
    if (!pr || pr.category === "Websites" || pr.category === "Domains") return J({ error: "A product is no longer available." }, 400);
    lines.push({ product_id: pr.id, category: pr.category, slot: pr.slot, n: pr.name, p: Number(pr.price), q }); total += Number(pr.price) * q;
  }
  total = Math.round(total * 100) / 100;
  const reference = "MW" + crypto.randomUUID().replace(/-/g, "").slice(0, 16).toUpperCase();
  const { data: pay, error } = await admin.from("payments").insert({ user_id: u.id, items: lines, amount: total, currency: Deno.env.get("CURRENCY") ?? "USD", phone_last4: phone.slice(-4), reference, status: "initiated" }).select("id").single();
  if (error || !pay) return J({ error: "Could not start the payment." }, 500);
  try {
    const g = await initiate({ reference, amount: total.toFixed(2), phone, email: Deno.env.get("PAYNOW_TEST_EMAIL") ?? u.email ?? "", returnurl: ORIGIN + "/", resulturl: Deno.env.get("SUPABASE_URL") + "/functions/v1/pay-webhook", info: "Macklywise order " + reference });
    await admin.from("payments").update({ status: "pending", poll_url: g.pollurl, gateway_ref: g.gwref }).eq("id", pay.id);
    return J({ id: pay.id, amount: total });
  } catch (e) {
    await admin.from("payments").update({ status: "failed", failure_reason: String((e as Error).message).slice(0, 200) }).eq("id", pay.id);
    return J({ error: "The payment could not be started. Please try again." }, 502);
  }
});
