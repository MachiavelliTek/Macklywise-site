import { admin } from "../_shared/common.ts";
import { verify } from "../_shared/paynow.ts";
import { settle } from "../_shared/settle.ts";
// Gateway callback. Deploy with --no-verify-jwt. The body is only a hint: we check its signature, then re-ask the gateway.
Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("ok");
  try {
    const v = await verify(await req.text());
    if (!v.ok) return new Response("bad signature", { status: 400 });
    const { data: p } = await admin.from("payments").select("*").eq("reference", v.o["reference"] ?? "").maybeSingle();
    if (p) await settle(p);
  } catch (_) { return new Response("error", { status: 500 }); }
  return new Response("ok");
});
