import { admin, J, pre, userOf, turnstile, ipOf } from "../_shared/common.ts";
// Comments and manual (WhatsApp) order records. Needs a login AND a passed Turnstile check; direct API inserts are blocked in SQL.
Deno.serve(async (req) => {
  const p = pre(req); if (p) return p;
  const u = await userOf(req); if (!u) return J({ error: "Please log in first." }, 401);
  let b: any; try { b = await req.json(); } catch { return J({ error: "Bad request" }, 400); }
  if (!(await turnstile(String(b.token ?? ""), ipOf(req)))) return J({ error: "Security check failed. Please try again." }, 403);
  const d = b.data ?? {};
  if (b.action === "comment") {
    const body = String(d.body ?? "").trim().slice(0, 500); if (!body) return J({ error: "Write something first." }, 400);
    const { data, error } = await admin.from("comments").insert({ testimonial_id: String(d.testimonial_id), user_id: u.id, body, reveal: d.reveal !== false }).select("id").single();
    return error ? J({ error: error.message.includes("Too many") ? "Slow down a little." : "Could not post." }, 429) : J({ id: data.id });
  }
  if (b.action === "order") {
    const items: any[] = []; let total = 0;
    for (const it of (Array.isArray(d.items) ? d.items.slice(0, 20) : [])) {
      const q = Math.min(Math.max(parseInt(it.q) || 1, 1), 20);
      const { data: pr } = await admin.from("products").select("category,slot,name,price").eq("category", String(it.category)).eq("slot", parseInt(it.slot)).maybeSingle();
      if (!pr) continue; items.push({ i: ["Workflows","Ebooks & Guides","Apps","Strategy PDFs","Logos","Websites","Domains"].indexOf(pr.category) * 12 + pr.slot, q, n: pr.name, p: Number(pr.price) }); total += Number(pr.price) * q;
    }
    if (!items.length) return J({ error: "Nothing to order." }, 400);
    const { data, error } = await admin.from("orders").insert({ user_id: u.id, items, total: Math.round(total * 100) / 100 }).select("id").single();
    return error ? J({ error: "Too many orders. Please wait." }, 429) : J({ id: data.id, items, total });
  }
  return J({ error: "Unknown action" }, 400);
});
