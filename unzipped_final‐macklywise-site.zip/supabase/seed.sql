-- Optional starter products (no files yet). Run after schema.sql.
insert into public.products(category,slot,name,description,price,format) values
('Workflows',0,'Lead-to-Invoice Automation','Captures a lead, sends a quote and invoice, then follows up automatically.',29,'JSON (n8n/Make)'),
('Workflows',1,'WhatsApp Auto-Reply & Booking','Answers common questions and books appointments around the clock.',24,'JSON + setup guide'),
('Workflows',2,'Social Content Scheduler','Turns one idea into a week of posts, scheduled for you.',19,'JSON'),
('Workflows',3,'Workflow Starter Bundle (10)','Ten of our best workflows in one pack, with install notes.',59,'JSON bundle'),
('Ebooks & Guides',0,'Start a Business in Zimbabwe','Registration, tax, banking and first customers, step by step.',12,'PDF ebook'),
('Ebooks & Guides',1,'Automate Your Business: Beginner’s Guide','Plain-language guide to saving hours with simple automations.',15,'PDF ebook'),
('Apps',0,'Invoice & Quote Generator','A simple app that produces clean invoices and quotes in USD or ZiG.',25,'HTML app + source'),
('Apps',1,'Stock & Sales Tracker','Track stock and daily sales in one lightweight tool.',29,'HTML app + source'),
('Strategy PDFs',0,'Retail Shop Growth Plan','Pricing, stock and promotion strategy for shops and tuck shops.',17,'PDF'),
('Strategy PDFs',1,'Restaurant & Takeaway Playbook','Menu, margins, delivery and repeat-customer tactics.',17,'PDF'),
('Strategy PDFs',2,'Salon & Beauty Business Plan','Bookings, retention and upsell playbook for salons.',17,'PDF'),
('Logos',0,'Logo Starter Pack','A custom logo with two revisions and full file set.',39,'PNG, SVG, PDF'),
('Websites',0,'One-Page Business Website','A fast, mobile-first landing page that turns visitors into enquiries.',149,'Live site'),
('Domains',0,'Domain Registration & Setup','We register and connect your domain, with email set up.',15,'Per year, from')
on conflict (category,slot) do nothing;
